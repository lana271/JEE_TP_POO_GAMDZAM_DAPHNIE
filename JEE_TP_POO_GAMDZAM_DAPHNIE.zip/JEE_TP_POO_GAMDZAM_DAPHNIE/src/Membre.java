public abstract  class Membre {
    protected String id;
    protected String nom;
    protected String email;

    public Membre(String id, String nom, String email) {
        this.id = id;
        this.nom = nom;
        this.email = email;
    }

    public String getId() { return id; }
    public String getNom() { return nom; }
    public String getEmail() { return email; }

    public void setNom(String nom) { this.nom = nom; }
    public void setEmail(String email) { this.email = email; }

    public abstract int getNombreMaxEmprunts();
    public abstract int getDureeEmprunt();
    public abstract void afficherInfo();
}
