public class Etudiant extends Membre {
    private String filiere;

    public Etudiant(String id, String nom, String email, String filiere) {
        super(id, nom, email);
        this.filiere = filiere;
    }

    @Override
    public int getNombreMaxEmprunts() {
        return 3;
    }

    @Override
    public int getDureeEmprunt() {
        return 14;
    }

    @Override
    public void afficherInfo() {
        System.out.println("[ETUDIANT] " + nom + " - Filière : " + filiere);
    }
}
