public class Emprunt {
    private Livre livre;
    private Membre membre;
    private String dateEmprunt;
    private String dateRetourPrevue;
    private boolean rendu;

    public Emprunt(Livre livre, Membre membre, String dateEmprunt, String dateRetourPrevue) {
        this.livre = livre;
        this.membre = membre;
        this.dateEmprunt = dateEmprunt;
        this.dateRetourPrevue = dateRetourPrevue;
        this.rendu = false;
        livre.setDisponible(false);
    }

    public void retournerLivre() {
        if (!rendu) {
            livre.setDisponible(true);
            rendu = true;
        }
    }

    public void afficherEmprunt() {
        System.out.println("Livre : " + livre.getTitre());
        System.out.println("Membre : " + membre.getNom());
        System.out.println("Date emprunt : " + dateEmprunt);
        System.out.println("Retour prévu : " + dateRetourPrevue);
        System.out.println("Rendu : " + (rendu ? "Oui" : "Non"));
    }

    public boolean isRendu() {
        return rendu;
    }
}
