public class Enseignant extends Membre  {
    private String departement;

    public Enseignant(String id, String nom, String email, String departement) {
        super(id, nom, email);
        this.departement = departement;
    }

    @Override
    public int getNombreMaxEmprunts() {
        return 5;
    }

    @Override
    public int getDureeEmprunt() {
        return 30;
    }

    @Override
    public void afficherInfo() {
        System.out.println("[ENSEIGNANT] " + nom + " - Département : " + departement);
    }
}
