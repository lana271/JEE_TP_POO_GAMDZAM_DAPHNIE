import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Bibliotheque b = new Bibliotheque("ENSPD Library");

        // Initialisation test
        b.ajouterLivre(new Livre("111", "Java", "Oracle", 2020));
        b.ajouterLivre(new Livre("222", "Python", "Guido", 2019));
        b.ajouterLivre(new Livre("333", "Algo", "Cormen", 2015));

        b.inscrireMembre(new Etudiant("E1", "Paul", "paul@mail.com", "INFO"));
        b.inscrireMembre(new Enseignant("T1", "Dr Jean", "jean@mail.com", "Math"));

        int choix;

        do {
            System.out.println("===== BIBLIOTHÈQUE ENSPD =====");
            System.out.println("1. Ajouter un livre");
            System.out.println("2. Inscrire un membre");
            System.out.println("3. Effectuer un emprunt");
            System.out.println("4. Retourner un livre");
            System.out.println("5. Rechercher un livre");
            System.out.println("6. Afficher livres disponibles");
            System.out.println("7. Afficher statistiques");
            System.out.println("0. Quitter");
            System.out.print("Votre choix : ");
            choix = sc.nextInt();
            sc.nextLine();

            switch (choix) {
                case 1:
                    System.out.print("ISBN : ");
                    String isbn = sc.nextLine();
                    System.out.print("Titre : ");
                    String titre = sc.nextLine();
                    System.out.print("Auteur : ");
                    String auteur = sc.nextLine();
                    System.out.print("Année : ");
                    int annee = sc.nextInt();
                    sc.nextLine();
                    b.ajouterLivre(new Livre(isbn, titre, auteur, annee));
                    System.out.println("Livre ajouté !");
                    break;

                case 2:
                    System.out.println("1. Étudiant  |  2. Enseignant");
                    int type = sc.nextInt(); sc.nextLine();
                    System.out.print("ID : "); String id = sc.nextLine();
                    System.out.print("Nom : "); String nom = sc.nextLine();
                    System.out.print("Email : "); String email = sc.nextLine();

                    if (type == 1) {
                        System.out.print("Filière : ");
                        String filiere = sc.nextLine();
                        b.inscrireMembre(new Etudiant(id, nom, email, filiere));
                    } else {
                        System.out.print("Département : ");
                        String dep = sc.nextLine();
                        b.inscrireMembre(new Enseignant(id, nom, email, dep));
                    }
                    System.out.println("Membre inscrit !");
                    break;

                case 3:
                    System.out.print("ISBN : ");
                    String is = sc.nextLine();
                    System.out.print("ID membre : ");
                    String mid = sc.nextLine();
                    b.effectuerEmprunt(is, mid, "01/01/2025");
                    break;

                case 6:
                    b.afficherLivresDisponibles();
                    break;

                case 7:
                    b.afficherStatistiques();
                    break;

                default: break;
            }

        } while (choix != 0);

        sc.close();
    }
}

