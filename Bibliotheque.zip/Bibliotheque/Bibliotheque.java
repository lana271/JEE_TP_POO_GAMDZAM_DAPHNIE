public class Bibliotheque {
     private String nom;
    private Livre[] livres = new Livre[100];
    private Membre[] membres = new Membre[50];
    private Emprunt[] emprunts = new Emprunt[200];

    private int nbLivres = 0;
    private int nbMembres = 0;
    private int nbEmprunts = 0;

    public Bibliotheque(String nom) {
        this.nom = nom;
    }

    public void ajouterLivre(Livre l) {
        livres[nbLivres++] = l;
    }

    public void inscrireMembre(Membre m) {
        membres[nbMembres++] = m;
    }

    public Livre rechercherLivreParTitre(String titre) {
        for (int i = 0; i < nbLivres; i++) {
            if (livres[i].getTitre().equalsIgnoreCase(titre))
                return livres[i];
        }
        return null;
    }

    public Membre rechercherMembreParId(String id) {
        for (int i = 0; i < nbMembres; i++) {
            if (membres[i].getId().equals(id))
                return membres[i];
        }
        return null;
    }

    public void effectuerEmprunt(String isbn, String idMembre, String date) {
        Livre l = null;
        for (int i = 0; i < nbLivres; i++) {
            if (livres[i].getIsbn().equals(isbn)) {
                l = livres[i];
                break;
            }
        }

        Membre m = rechercherMembreParId(idMembre);

        if (l == null || m == null || !l.isDisponible()) {
            System.out.println("Erreur : emprunt impossible");
            return;
        }

        String dateRetour = "Voir durée selon membre"; // simplification
        emprunts[nbEmprunts++] = new Emprunt(l, m, date, dateRetour);
        System.out.println("Emprunt réussi !");
    }

    public void afficherLivresDisponibles() {
        for (int i = 0; i < nbLivres; i++) {
            if (livres[i].isDisponible()) {
                livres[i].afficherDetails();
                System.out.println("-------------------");
            }
        }
    }

    public void afficherStatistiques() {
        int dispo = 0;
        int etudiants = 0;
        int enseignants = 0;
        int empruntsEnCours = 0;

        for (int i = 0; i < nbLivres; i++)
            if (livres[i].isDisponible()) dispo++;

        for (int i = 0; i < nbMembres; i++) {
            if (membres[i] instanceof Etudiant) etudiants++;
            else enseignants++;
        }

        for (int i = 0; i < nbEmprunts; i++)
            if (!emprunts[i].isRendu()) empruntsEnCours++;

        System.out.println("Total livres : " + nbLivres);
        System.out.println("Disponibles : " + dispo);
        System.out.println("Étudiants : " + etudiants);
        System.out.println("Enseignants : " + enseignants);
        System.out.println("Emprunts en cours : " + empruntsEnCours);
        System.out.println("Taux occupation : " + (100 * empruntsEnCours / nbLivres) + "%");
    }
}
